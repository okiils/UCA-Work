
#include "Faucet.h"
#include "Container.h"
#include "graph1.h"
#include "Simulation.h"

const double PI = 3.14;

	Simulation::Simulation()
	{
		waterRate = 0;
		container.setHeight(0);
	}
	void Simulation::setContainer(Container container)
	{
		this->container.setCol(container.getColor());
		this->container.setHeight(container.getHeight());
		this->container.setPosition(container.getPosition());
		this->container.setRadius(container.getRadius());
	}
	Container Simulation::getContainer()
	{
		return container;
	}
	void Simulation::setFaucet(Faucet faucet)
	{
		this->faucet.setFluid(faucet.getFluid());
		this->faucet.setPosition(faucet.getPosition());
	}
	Faucet Simulation::getFaucet()
	{
		return faucet;
	}
	int Simulation::getWaterRate()
	{
		return waterRate;
	}
	void Simulation::setWaterRate(int waterRate)
	{
		this->waterRate = waterRate;
	}
	void Simulation::draw()
	{
		//Background drawings
			int wall = 0;
			int ground = 0;
			int pipe = 0;

			wall = drawRect(0, 0, 55, 400);
			setColor(wall, 200, 200, 200);

			ground = drawRect(0, 400, 640, 80);
			setColor(ground, 71, 35, 35);


			container.draw();

				
			//Display For the Faucet
			faucet.draw();
	}
	void Simulation::start()
	{
		faucet.turnOn();

		int stream = 0;
		int poured = 0;
		double conv_flow_rate = (3785411.78 * waterRate) / 60;
		int new_fill_line = 395;
		int diameter = container.getRadius() * 2;
		int wall_size = 5;

		//Data Validation for Change in Height
		int change_in_height = conv_flow_rate / (PI * pow(container.getRadius(), 2.0));
		if (change_in_height < 1)
		{
			change_in_height = 1.0;
		}
		if (change_in_height > container.getHeight())
		{
			change_in_height = container.getHeight();
		}
		new_fill_line = 395 - change_in_height;
		
		//Fill the container Gradually, decrementing the calculated fill line as it fills
		for (int i = 0; new_fill_line > faucet.getFluid().getFillLine(); i++)
		{
			Sleep(100);
			
			poured = drawRect((container.getPosition().getX()) + wall_size, new_fill_line, diameter - (wall_size * 2), change_in_height);
			setColor(poured, faucet.getFluid().getColor().getRed(), faucet.getFluid().getColor().getGreen(), faucet.getFluid().getColor().getBlue());
			new_fill_line -= (int)change_in_height;

		}
		//Print the Filled Rectangle as a Whole To Fill the Container
		poured = drawRect((container.getPosition().getX()) + wall_size, faucet.getFluid().getFillLine(), diameter - (wall_size * 2), container.getHeight()-wall_size);
		setColor(poured, faucet.getFluid().getColor().getRed(), faucet.getFluid().getColor().getGreen(), faucet.getFluid().getColor().getBlue());

		faucet.turnOff();
	}

