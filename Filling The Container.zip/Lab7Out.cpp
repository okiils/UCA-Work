//Owen Kiilsgaard
//Lab 7 Out
//Gets Container Dimensions and fluid type from user, and fills the container

#include <iostream>
#include "graph1.h"
#include "Simulation.h"
#include "Fluid.h"
#include "Faucet.h"


using namespace std;

int main()
{
    //Variable Declaration/Initialization
    int height = 0;
    int radius = 0;
    int r = 0;
    int b = 0;
    int g = 0;
    int flow_rate;
    int faucetx = 0;
    int FAUCET_WIDTH = 64;
    string substance;
    char repeat;
    Container container;
    Simulation simulation;
    Color col;
    GenPoint position;
    GenPoint faucet_pos;
    GenPoint fluid_start;
    GenPoint fluid_stop;
    Faucet spout;
    Fluid liquid;

    //Display the graphics
    displayGraphics();

    //Continually simulate

    do
    {
        //Get the Container's radius/height/color (Add Data Validation)
         cout << "Enter fluid flow rate: ";
            cin >> flow_rate;
            while (flow_rate < 1 || flow_rate >30)
            {
                cout << "\nEnter A Valid Flow Rate: ";
                cin >> flow_rate;
            }

            cout << "\nEnter radius of container(between 10 and 285): ";
            cin >> radius;

            while (radius < 10 || radius > 285)
            {
                cout << "Error, invalid radius entered, Try again.(10-285) \n";
                cin >> radius;
            }
            
            cout << "Enter height of container(between 10 and 300): ";
            cin >> height;

            while (height < 10 || height > 300)
            {
                cout << "Error, invalid height entered, Try again.(10-300) \n";
                cin >> height;
            }
            
            cout << "Enter color of Container: ";
            cin >> r>> g>> b;

            while (r < 0 || r> 255 || g < 0 || g>255 || b < 0 || b > 255)
            {
                cout << "Error, invalid RGB entered. Try again.(0_255)\n";
                cin >> r >> g >> b;

            }


        //Get Fluid Type From the User
        cin.ignore();
        cout << "Enter Fluid Name <water, oil, or diesel>: ";
        getline(cin, substance);

        liquid.setFluidName(substance);
        
 
        //Liquid Information
        //50 for concrete, 5 for container wall
        fluid_start.setPoint(50 + 5 + radius, 64);
        fluid_stop.setPoint(50 + 5 + radius, 395);
        liquid.setStart(fluid_start);
        liquid.setEnd(fluid_stop);
        liquid.setFillLine(395-height);
        //480-(80)ground -container(5)
       
      
        //Faucet Information
        faucetx = (radius - FAUCET_WIDTH) + 50;
        faucet_pos.setPoint(faucetx, 12);
        spout.setPosition(faucet_pos);
        spout.setFluid(liquid);
        
         
         
        //Set the Containers radius/height /color
        container.setRadius(radius);
        container.setHeight(height);
        col.setColor(r, g, b);
        container.setCol(col);

        //Compute the Container upper left coordinate based on the height
        //Set the Container�s position
        //Hint: 55, 400 - height
        position.setPoint(60, 400 - height);
        container.setPosition(position);


        
        //Set the Container for the Simulation
        simulation.setContainer(container);

        //Simulate Faucet
        simulation.setFaucet(spout); 

        //Water Rate
        simulation.setWaterRate(flow_rate);

        //Draw the simulation/container (invoke draw on Simulation)
        simulation.draw();


        simulation.start();
        
        

        //Repeat the simulation?
        cout << "Repeat the simulation (y/n)? ";
        cin >> repeat;

        clearGraphics();
        system("cls");

    } while (repeat == 'y' || repeat == 'Y');

    return 0;
}

