#include "GenPoint.h"
#include "Fluid.h"
#include "graph1.h"
#include "Faucet.h"

    Faucet::Faucet()
    {
        pos.setPoint(0, 0);
    }
    void Faucet::turnOn()
    {
        int stream = 0;
        int wall_size = 5;
        int faucet_size = 65;

        stream = drawLine(getFluid().getStart().getX(), getFluid().getStart().getY(), getFluid().getEnd().getX(), getFluid().getEnd().getY(),1);
        setColor(stream, fluid.getColor().getRed(), fluid.getColor().getGreen(), fluid.getColor().getBlue());
        
    }
    void Faucet::turnOff()
    {
        int stream = 0;
        int wall_size = 5;
        int faucet_size = 65;

        stream = drawLine(getFluid().getStart().getX(), getFluid().getStart().getY(), getFluid().getEnd().getX(),getFluid().getFillLine(), 1);
        setColor(stream, 0,0,0);

    }
    void Faucet::setPosition(GenPoint upper)
    {
        this->pos = upper;
    }
    GenPoint Faucet::getPosition()
    {
        return pos;
    }
    void Faucet::setFluid(Fluid fluid)
    {
        this->fluid.setFillLine(fluid.getFillLine());
        this->fluid.setEnd(fluid.getEnd());
        this->fluid.setFluidName(fluid.getFluidName());
        this->fluid.setStart(fluid.getStart());
    }
    Fluid Faucet::getFluid()
    {
        return fluid;
    }
    void Faucet::draw()
    {
        int pipe = 0;
        int wall_size = 5;
        displayBMP("faucet.bmp", pos.getX() + wall_size, pos.getY());
        pipe = drawLine(54, 50, pos.getX() + wall_size, 50, 5);
        setColor(pipe, 80, 80, 80);
    }